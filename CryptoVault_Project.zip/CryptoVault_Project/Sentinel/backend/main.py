from http.server import BaseHTTPRequestHandler, HTTPServer
import json, time, os

HOST, PORT = "127.0.0.1", 8002
START=time.time()

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path=="/api/status":
            data={"service":"Sentinel","status":"healthy","uptime_seconds":round(time.time()-START,1),"pid":os.getpid()}
            raw=json.dumps(data).encode()
            self.send_response(200); self.send_header("Content-Type","application/json")
            self.send_header("Access-Control-Allow-Origin","*"); self.end_headers(); self.wfile.write(raw)
        else:
            self.send_response(404); self.end_headers()

if __name__=="__main__":
    print(f"Sentinel backend running at http://{HOST}:{PORT}")
    HTTPServer((HOST,PORT),Handler).serve_forever()
