# SecureTunnel
1. Run `python main.py` inside `backend`.
2. Open `frontend/index.html` using Live Server.
3. The frontend uses the Python API on port 8001.
