from http.server import BaseHTTPRequestHandler, HTTPServer
import json, base64

HOST, PORT = "127.0.0.1", 8001

def xor_bytes(data: bytes, key: str) -> bytes:
    k = key.encode()
    return bytes(b ^ k[i % len(k)] for i, b in enumerate(data))

class Handler(BaseHTTPRequestHandler):
    def send_json(self, obj, code=200):
        raw=json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type","application/json")
        self.send_header("Access-Control-Allow-Origin","*")
        self.send_header("Access-Control-Allow-Headers","Content-Type")
        self.end_headers()
        self.wfile.write(raw)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin","*")
        self.send_header("Access-Control-Allow-Headers","Content-Type")
        self.send_header("Access-Control-Allow-Methods","POST, OPTIONS")
        self.end_headers()

    def do_GET(self):
        if self.path == "/api/status":
            self.send_json({"service":"SecureTunnel","status":"running","port":PORT})
        else:
            self.send_json({"error":"Not found"},404)

    def do_POST(self):
        if self.path not in ("/api/encrypt","/api/decrypt"):
            return self.send_json({"error":"Not found"},404)
        n=int(self.headers.get("Content-Length","0"))
        data=json.loads(self.rfile.read(n) or "{}")
        text=data.get("text",""); key=data.get("key","")
        if not key: return self.send_json({"error":"Key required"},400)
        if self.path.endswith("encrypt"):
            result=base64.b64encode(xor_bytes(text.encode(),key)).decode()
        else:
            try: result=xor_bytes(base64.b64decode(text),key).decode()
            except Exception: return self.send_json({"error":"Invalid encrypted text"},400)
        self.send_json({"result":result})

if __name__=="__main__":
    print(f"SecureTunnel backend running at http://{HOST}:{PORT}")
    HTTPServer((HOST,PORT),Handler).serve_forever()
