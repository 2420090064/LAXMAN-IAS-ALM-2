# CryptoVault / SecureTunnel / Sentinel

This package follows the folder layout requested:

- CryptoVault/frontend
- SecureTunnel/backend + frontend
- Sentinel/backend + frontend

## Run order

### 1. CryptoVault
Open `CryptoVault/frontend/index.html` with VS Code Live Server.

### 2. SecureTunnel
Terminal 1:
`cd SecureTunnel/backend`
`python main.py`

Terminal 2:
Open `SecureTunnel/frontend/index.html` with Live Server.

### 3. Sentinel
Terminal 1:
`cd Sentinel/backend`
`python main.py`

Terminal 2:
Open `Sentinel/frontend/index.html` with Live Server.

Note: these files are a clean generated implementation matching the requested structure. They are not a reconstruction of unavailable original source files.
