const algorithm=document.getElementById("algorithm"), input=document.getElementById("inputText"), key=document.getElementById("key"), output=document.getElementById("outputText");

function caesar(text, shift){shift=Number(shift);return [...text].map(c=>{if(/[A-Z]/.test(c))return String.fromCharCode((c.charCodeAt(0)-65+shift+2600)%26+65);if(/[a-z]/.test(c))return String.fromCharCode((c.charCodeAt(0)-97+shift+2600)%26+97);return c}).join("")}
function vig(text,k,dec=false){k=k.toUpperCase().replace(/[^A-Z]/g,"");if(!k)return "";let i=0;return [...text].map(c=>{if(!/[A-Za-z]/.test(c))return c;let b=c===c.toUpperCase()?65:97,s=k.charCodeAt(i++%k.length)-65;return String.fromCharCode((c.charCodeAt(0)-b+(dec?-s:s)+26)%26+b)}).join("")}
function xor(text,k){if(!k)return "";let r="";for(let i=0;i<text.length;i++)r+=String.fromCharCode(text.charCodeAt(i)^k.charCodeAt(i%k.length));return r}

document.getElementById("encryptBtn").onclick=()=>run(false);
document.getElementById("decryptBtn").onclick=()=>run(true);
document.getElementById("clearBtn").onclick=()=>{input.value="";key.value="";output.value=""};

function run(dec){
 if(!input.value||!key.value){alert("Enter text and key.");return}
 const a=algorithm.value;
 output.value=a==="caesar"?caesar(input.value,dec?-Number(key.value):Number(key.value)):a==="vigenere"?vig(input.value,key.value,dec):xor(input.value,key.value);
}
