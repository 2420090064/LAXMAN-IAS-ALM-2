# CryptoVault
Open `index.html` with Live Server.

Supported algorithms:
- Caesar Cipher
- Vigenère Cipher
- XOR Cipher
